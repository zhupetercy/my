package cn.edu.bistu.cs.ir.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * 面向新浪博客的模型类
 * @author chenruoyu
 */
@Getter
@Setter
public class Blog {

    /**
     * 页面的唯一ID
     */
    private String id;

    /**
     * 标题
     */
    private String title;

    /**
     * 日期
     */
    private long date;


    private String dateStr;  // 可读日期字符串

    public String getDateStr() { return dateStr; }
    public void setDateStr(String dateStr) { this.dateStr = dateStr; }
    /**
     * 正文内容
     */
    private String content;

    /**
     * 作者
     */
    private String author;

    /**
     * 标签
     */
    private List<String> tags;

    /**
     * 动态获取的博文信息
     */
    private BlogStats blogStats;


    // 在 Blog.java 中添加
    // 和其他字段放在一起，比如放在 tags 字段旁边
    private String category;

    // 和其他 getter/setter 放在一起
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
