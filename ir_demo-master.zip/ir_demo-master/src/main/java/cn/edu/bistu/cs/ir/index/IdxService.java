package cn.edu.bistu.cs.ir.index;

import cn.edu.bistu.cs.ir.config.Config;
import cn.edu.bistu.cs.ir.utils.StringUtil;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.*;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.*;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.TermQuery;

/**
 * 面向<a href="https://lucene.apache.org/">Lucene</a>
 * 索引读、写的服务类
 * @author chenruoyu
 */
@Component
public class IdxService implements DisposableBean {

    private static final Logger log = LoggerFactory.getLogger(IdxService.class);

    private static final Class<? extends Analyzer> DEFAULT_ANALYZER = StandardAnalyzer.class;

    IndexWriter writer;

    public IdxService(@Autowired Config config) throws Exception {
        Analyzer analyzer = DEFAULT_ANALYZER.getConstructor().newInstance();
        Directory index;
        try {
            index = FSDirectory.open(Paths.get(config.getIdx()));
            IndexWriterConfig writerConfig = new IndexWriterConfig(analyzer);
            writer = new IndexWriter(index, writerConfig);
            log.info("索引初始化完成，索引目录为:[{}]", config.getIdx());
        } catch (IOException e) {
            e.printStackTrace();
            log.error("无法初始化索引，请检查提供的索引目录是否可用:[{}]", config.getIdx());
            writer = null;
        }
    }

    public boolean addDocument(String idFld, String id, Document doc){
        if(writer==null||doc==null){
            log.error("Writer对象或文档对象为空，无法添加文档到索引中");
            return false;
        }
        if(StringUtil.isEmpty(idFld)||StringUtil.isEmpty(id)){
            log.error("ID字段名或ID字段值为空，无法添加文档到索引中");
            return false;
        }
        try {
            writer.updateDocument(new Term(idFld, id), doc);
            writer.commit();
            log.info("成功将ID为[{}]的文档加入索引", id);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            log.error("构建索引失败");
            return false;
        }
    }

    /**
     * 根据关键词对索引内容进行检索，并将检索结果返回
     * @param kw 待检索的关键词
     * @return 检索得到的文档列表
     */
    public List<Document> queryByKw(String kw) throws Exception{
        //打开准实时索引Reader
        DirectoryReader reader = DirectoryReader.open(writer);
        IndexSearcher searcher = new IndexSearcher(reader);
        Analyzer analyzer = DEFAULT_ANALYZER.getConstructor().newInstance();
        QueryParser parser = new QueryParser("TITLE", analyzer);
        Query query = parser.parse(kw);
        TopDocs docs =searcher.search(query, 10);
        ScoreDoc[] hits = docs.scoreDocs;
        List<Document> results = new ArrayList<>();
        for (ScoreDoc doc : hits) {
            results.add(searcher.doc(doc.doc));
        }
        return results;
    }

    //TODO 请大家在这里添加更多的检索函数，如针对发表时间的范围检索等，
    // 添加了检索函数后，还需要相应地在Controller中添加接口


    // ===================== 简单检索：获取总文档数 =====================
    public int getTotalDocs() throws Exception {
        try (DirectoryReader reader = DirectoryReader.open(writer)) {
            return reader.numDocs();
        }
    }

    // ===================== 简单检索：按标题检索 =====================
    public List<Document> searchByTitle(String kw, int size) throws Exception {
        try (DirectoryReader reader = DirectoryReader.open(writer)) {
            IndexSearcher searcher = new IndexSearcher(reader);
            QueryParser parser = new QueryParser("TITLE", new StandardAnalyzer());
            TopDocs docs = searcher.search(parser.parse(kw), size);
            return getDocuments(searcher, docs);
        }
    }

    // ===================== 复合检索：BooleanQuery（标题+内容） =====================
    public List<Document> searchTitleAndContent(String titleKw, String contentKw, int size) throws Exception {
        try (DirectoryReader reader = DirectoryReader.open(writer)) {
            IndexSearcher searcher = new IndexSearcher(reader);
            Analyzer analyzer = new StandardAnalyzer();

            Query q1 = new QueryParser("TITLE", analyzer).parse(titleKw);
            Query q2 = new QueryParser("CONTENT", analyzer).parse(contentKw);

            BooleanQuery.Builder bq = new BooleanQuery.Builder();
            bq.add(q1, BooleanClause.Occur.MUST);
            bq.add(q2, BooleanClause.Occur.MUST);

            TopDocs topDocs = searcher.search(bq.build(), size);
            return getDocuments(searcher, topDocs);
        }
    }

    // ===================== 复合检索：QueryParser（标题OR内容） =====================
    public List<Document> searchByQueryParser(String kw, int size) throws Exception {
        try (DirectoryReader reader = DirectoryReader.open(writer)) {
            IndexSearcher searcher = new IndexSearcher(reader);
            String queryStr = "TITLE:" + kw + " OR CONTENT:" + kw;
            QueryParser parser = new QueryParser("", new StandardAnalyzer());
            TopDocs docs = searcher.search(parser.parse(queryStr), size);
            return getDocuments(searcher, docs);
        }
    }

    // ===================== 日期范围检索 =====================
    public List<Document> searchByDateRange(long start, long end, int size) throws Exception {
        try (DirectoryReader reader = DirectoryReader.open(writer)) {
            IndexSearcher searcher = new IndexSearcher(reader);
            Query q = LongPoint.newRangeQuery("DATE", start, end);
            TopDocs docs = searcher.search(q, size);
            return getDocuments(searcher, docs);
        }
    }

    // 工具方法
    private List<Document> getDocuments(IndexSearcher searcher, TopDocs topDocs) throws Exception {
        List<Document> list = new ArrayList<>();
        for (ScoreDoc sd : topDocs.scoreDocs) {
            list.add(searcher.doc(sd.doc));
        }
        return list;
    }




    @Override
    public void destroy(){
        if(this.writer==null){
            return;
        }
        try {
            log.info("索引关闭");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
            log.info("尝试关闭索引失败");
        }
    }
}
