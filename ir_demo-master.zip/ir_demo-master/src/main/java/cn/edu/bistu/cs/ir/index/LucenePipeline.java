package cn.edu.bistu.cs.ir.index;

import cn.edu.bistu.cs.ir.crawler.CnBlogsCrawler;
import cn.edu.bistu.cs.ir.model.Blog;
import cn.edu.bistu.cs.ir.model.BlogStats;
import org.apache.lucene.document.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import us.codecraft.webmagic.ResultItems;
import us.codecraft.webmagic.Task;
import us.codecraft.webmagic.pipeline.Pipeline;

import java.util.List;

public class LucenePipeline implements Pipeline {
    private static final Logger log = LoggerFactory.getLogger(LucenePipeline.class);
    private final IdxService idxService;

    public LucenePipeline(IdxService idxService){
        log.info("初始化LucenePipeline模块");
        this.idxService = idxService;
    }

    @Override
    public void process(ResultItems resultItems, Task task) {
        Blog blog = resultItems.get(CnBlogsCrawler.RESULT_ITEM_KEY);
        if(blog==null) {
            log.error("未获取到Blog对象");
            return;
        }
        Document doc = toDoc(blog);
        idxService.addDocument("ID", blog.getId(), doc);
    }

    // ===================== 实验二要求：索引字段 =====================
    private Document toDoc(Blog blog){
        Document document = new Document();

        // 1. 文章ID（修复 null）
        String id = blog.getId();
        if (id == null || id.isEmpty()) {
            id = "blog-" + System.currentTimeMillis(); // 自动生成ID
        }
        document.add(new StringField("id", id, Field.Store.YES));

        // 2. 标题
        document.add(new TextField("TITLE", blog.getTitle(), Field.Store.YES));

        // 3. 作者
        document.add(new StringField("AUTHOR", blog.getAuthor(), Field.Store.YES));

        // 4. 发表时间（时间戳 + 字符串时间都存）
        long dateTime = blog.getDate();
        document.add(new LongPoint("DATE", dateTime));
        document.add(new StoredField("TIME_STORE", dateTime));
        document.add(new StoredField("DATE_STR", blog.getDateStr()));

        // 5. 博文内容
        document.add(new TextField("CONTENT", blog.getContent(), Field.Store.YES));

        // 6. 标签（List 转字符串，修复 null）
        String tag = "默认标签";
        document.add(new TextField("tag", tag, Field.Store.YES));

        // 7. 分类（修复 null）
        String category = blog.getCategory();
        if (category == null || category.trim().isEmpty()) {
            category = "默认分类";
        }
        document.add(new StringField("category", category, Field.Store.YES));

        // 8. 文章URL（固定拼接）
        String url = "https://www.cnblogs.com/tencent-cloud-native/p/" + blog.getId() + ".html";
        document.add(new StoredField("URL", url));

        return document;
    }
}