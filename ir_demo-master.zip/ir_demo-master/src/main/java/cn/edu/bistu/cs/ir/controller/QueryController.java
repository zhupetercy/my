package cn.edu.bistu.cs.ir.controller;

import cn.edu.bistu.cs.ir.index.IdxService;
import cn.edu.bistu.cs.ir.utils.QueryResponse;
import org.apache.lucene.document.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.FileWriter;
import java.io.PrintWriter;


import java.util.*;

/**
 * 面向检索服务接口的控制器类
 * Restful Web Services/Rest风格的Web服务
 * @author chenruoyu
 */
@RestController
@RequestMapping("/query")
public class QueryController {

    private static final Logger log = LoggerFactory.getLogger(QueryController.class);


    private final IdxService idxService;

    public QueryController(@Autowired IdxService idxService){
        this.idxService = idxService;
    }


    /**
     * 根据关键词对索引进行分页检索，
     * 根据页号和页面大小，
     * 返回指定页的数据记录
     * @param kw 待检索的关键词
     * @param pageNo 页号，默认为1
     * @param pageSize 页的大小，默认为10
     * @return 检索得到的结果记录，以<页面ID, 页面标题>二元组的形式返回
     */






    @GetMapping(value = "/kw", produces = "application/json;charset=UTF-8")
    public QueryResponse<List<Map<String, String>>> queryByKw(@RequestParam(name = "kw") String kw,
                                                                    @RequestParam(name = "pageNo", defaultValue = "1") int pageNo,
                                                                    @RequestParam(name = "pageSize", defaultValue = "10") int pageSize){
        try {
            // 1. 先获取关键词检索的全部结果
            List<Document> docs = idxService.queryByKw(kw);

            // ========== 新增日志代码 start ==========

            try {
                java.io.FileWriter fw = new java.io.FileWriter("C:/Users/zcy20/Desktop/索引结果.txt");
                fw.write("===== 博客检索结果（完整字段）=====\r\n");
                fw.write("检索总数：" + docs.size() + "\r\n\r\n");

                for (int i = 0; i < docs.size(); i++) {
                    org.apache.lucene.document.Document doc = docs.get(i);

                    fw.write("第 " + (i + 1) + " 篇\r\n");
                    fw.write("文章ID    ：" + doc.get("ID") + "\r\n");
                    fw.write("文章标题  ：" + doc.get("TITLE") + "\r\n");
                    fw.write("作者      ：" + doc.get("AUTHOR") + "\r\n");
                    fw.write("发表时间  ：" + doc.get("DATE_STR") + "\r\n");
                    fw.write("文章内容  ：" + doc.get("CONTENT") + "\r\n");
                    fw.write("标签      ：" + doc.get("TAG") + "\r\n");
                    fw.write("分类      ：" + doc.get("CATEGORY") + "\r\n");
                    fw.write("文章URL   ：" + doc.get("URL") + "\r\n");
                    fw.write("----------------------------------------\r\n\r\n");
                }
                fw.close();
                System.out.println("完整结果已保存到桌面！");
            } catch (Exception e) {
                e.printStackTrace();
            }
            // ========== 新增日志代码 end ==========

            // ========== 新增分页逻辑（核心修改位置）==========
            // 校验分页参数（避免页号/页大小为负数）
            pageNo = Math.max(pageNo, 1);
            pageSize = Math.max(pageSize, 1);

            // 计算分页起始/结束索引
            int totalCount = docs.size();
            int startIndex = (pageNo - 1) * pageSize;
            int endIndex = Math.min(startIndex + pageSize, totalCount);

            // 截取当前页的数据（若起始索引超过总数，返回空列表）
            List<Document> pageDocs = new ArrayList<>();
            if (startIndex < totalCount) {
                pageDocs = docs.subList(startIndex, endIndex);
            }
            // ========== 分页逻辑结束 ==========

            // 2. 封装当前页数据为返回格式
            List<Map<String, String>> results = new ArrayList<>();
            for(Document doc : pageDocs){  // 注意：这里改用分页后的pageDocs
                Map<String, String> record = new HashMap<>(2);
                record.put("ID", doc.get("ID"));
                record.put("TITLE", doc.get("TITLE"));
                record.put("TIME", doc.get("TIME_STORE"));
                results.add(record);
            }

            // 3. 返回结果（可扩展：把总条数、总页数也返回，方便前端展示）
            Map<String, Object> extra = new HashMap<>();
            extra.put("totalCount", totalCount);
            extra.put("totalPage", (totalCount + pageSize - 1) / pageSize); // 向上取整计算总页数
            extra.put("currentPage", pageNo);
            extra.put("pageSize", pageSize);

            // 若需要返回分页元数据，用genSucc的重载方法（需确认QueryResponse是否支持；若不支持，仍用原写法）
            // return QueryResponse.genSucc("检索成功", results, extra);
            // 若QueryResponse无重载，仍用原返回方式：
            return QueryResponse.genSucc("检索成功", results);

        } catch (Exception e) {
            log.error("检索过程中发生异常:[{}]", e.getMessage());
            return QueryResponse.genErr("检索过程中发生异常");
        }
    }
}
