package com.example.exp;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ContentUris;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.exp.data.TaskContract;
import com.example.exp.util.DateTimeUtil;
import com.example.exp.util.ReminderUtil;

import java.util.Calendar;

public class AddTaskActivity extends AppCompatActivity {
    private EditText titleEditText;
    private EditText contentEditText;
    private Button deadlineButton;
    private Button remindTimeButton;
    private RadioGroup priorityRadioGroup;

    private long deadlineTime;
    private long remindTime;
    private long editingTaskId = -1;
    private int editingCompleted = TaskContract.TaskEntry.STATUS_UNCOMPLETED;
    private int editingReminded = TaskContract.TaskEntry.REMINDED_NO;
    private long editingCreatedAt = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_task);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        titleEditText = findViewById(R.id.etTaskTitle);
        contentEditText = findViewById(R.id.etTaskContent);
        deadlineButton = findViewById(R.id.btnDeadline);
        remindTimeButton = findViewById(R.id.btnRemindTime);
        priorityRadioGroup = findViewById(R.id.rgPriority);

        ImageButton backButton = findViewById(R.id.btnBack);
        backButton.setOnClickListener(v -> finish());

        deadlineButton.setOnClickListener(v -> showDateTimePicker(true));
        remindTimeButton.setOnClickListener(v -> showDateTimePicker(false));

        Button saveButton = findViewById(R.id.btnSaveTask);
        saveButton.setOnClickListener(v -> saveTask());

        editingTaskId = getIntent().getLongExtra(TaskDetailActivity.EXTRA_TASK_ID, -1);
        if (editingTaskId > 0) {
            loadTaskForEdit();
        }
    }

    private void showDateTimePicker(boolean isDeadline) {
        Calendar calendar = Calendar.getInstance();
        long selectedTime = isDeadline ? deadlineTime : remindTime;
        if (selectedTime > 0) {
            calendar.setTimeInMillis(selectedTime);
        }

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    Calendar selectedCalendar = Calendar.getInstance();
                    selectedCalendar.set(Calendar.YEAR, year);
                    selectedCalendar.set(Calendar.MONTH, month);
                    selectedCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                    showTimePicker(isDeadline, selectedCalendar);
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }

    private void showTimePicker(boolean isDeadline, Calendar selectedCalendar) {
        Calendar current = Calendar.getInstance();
        long selectedTime = isDeadline ? deadlineTime : remindTime;
        if (selectedTime > 0) {
            current.setTimeInMillis(selectedTime);
        }

        TimePickerDialog timePickerDialog = new TimePickerDialog(
                this,
                (view, hourOfDay, minute) -> {
                    selectedCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    selectedCalendar.set(Calendar.MINUTE, minute);
                    selectedCalendar.set(Calendar.SECOND, 0);
                    selectedCalendar.set(Calendar.MILLISECOND, 0);

                    long timeMillis = selectedCalendar.getTimeInMillis();
                    if (isDeadline) {
                        deadlineTime = timeMillis;
                        deadlineButton.setText(DateTimeUtil.formatDateTime(deadlineTime));
                    } else {
                        remindTime = timeMillis;
                        remindTimeButton.setText(DateTimeUtil.formatDateTime(remindTime));
                    }
                },
                current.get(Calendar.HOUR_OF_DAY),
                current.get(Calendar.MINUTE),
                true
        );
        timePickerDialog.show();
    }

    private void saveTask() {
        String title = titleEditText.getText().toString().trim();
        String content = contentEditText.getText().toString().trim();

        if (title.isEmpty()) {
            Toast.makeText(this, R.string.please_input_title, Toast.LENGTH_SHORT).show();
            return;
        }
        if (deadlineTime <= 0) {
            Toast.makeText(this, R.string.please_select_deadline, Toast.LENGTH_SHORT).show();
            return;
        }
        if (remindTime <= 0) {
            Toast.makeText(this, R.string.please_select_remind_time, Toast.LENGTH_SHORT).show();
            return;
        }
        if (remindTime < System.currentTimeMillis()) {
            Toast.makeText(this, R.string.remind_time_too_early, Toast.LENGTH_SHORT).show();
            return;
        }
        if (deadlineTime < remindTime) {
            Toast.makeText(this, R.string.deadline_before_remind, Toast.LENGTH_SHORT).show();
            return;
        }

        ContentValues values = new ContentValues();
        values.put(TaskContract.TaskEntry.COLUMN_TITLE, title);
        values.put(TaskContract.TaskEntry.COLUMN_CONTENT, content);
        values.put(TaskContract.TaskEntry.COLUMN_DEADLINE_TIME, deadlineTime);
        values.put(TaskContract.TaskEntry.COLUMN_REMIND_TIME, remindTime);
        values.put(TaskContract.TaskEntry.COLUMN_PRIORITY, getSelectedPriority());

        long savedTaskId;
        if (editingTaskId > 0) {
            values.put(TaskContract.TaskEntry.COLUMN_COMPLETED, editingCompleted);
            values.put(TaskContract.TaskEntry.COLUMN_REMINDED, editingReminded);
            values.put(TaskContract.TaskEntry.COLUMN_CREATED_AT, editingCreatedAt);

            Uri taskUri = ContentUris.withAppendedId(TaskContract.TaskEntry.CONTENT_URI, editingTaskId);
            int updated = getContentResolver().update(taskUri, values, null, null);
            if (updated <= 0) {
                Toast.makeText(this, R.string.task_update_failed, Toast.LENGTH_SHORT).show();
                return;
            }
            savedTaskId = editingTaskId;
            Toast.makeText(this, R.string.task_update_success, Toast.LENGTH_SHORT).show();
        } else {
            values.put(TaskContract.TaskEntry.COLUMN_COMPLETED, TaskContract.TaskEntry.STATUS_UNCOMPLETED);
            values.put(TaskContract.TaskEntry.COLUMN_REMINDED, TaskContract.TaskEntry.REMINDED_NO);
            values.put(TaskContract.TaskEntry.COLUMN_CREATED_AT, System.currentTimeMillis());

            // 页面通过 ContentResolver 写入数据，保持 Activity 和 SQLite 解耦。
            Uri resultUri = getContentResolver().insert(TaskContract.TaskEntry.CONTENT_URI, values);
            if (resultUri == null) {
                Toast.makeText(this, R.string.task_save_failed, Toast.LENGTH_SHORT).show();
                return;
            }
            savedTaskId = ContentUris.parseId(resultUri);
            Toast.makeText(this, R.string.task_save_success, Toast.LENGTH_SHORT).show();
        }

        ReminderUtil.scheduleReminder(this, savedTaskId, remindTime);
        finish();
    }

    private int getSelectedPriority() {
        int checkedId = priorityRadioGroup.getCheckedRadioButtonId();
        if (checkedId == R.id.rbPriorityLow) {
            return TaskContract.TaskEntry.PRIORITY_LOW;
        }
        if (checkedId == R.id.rbPriorityHigh) {
            return TaskContract.TaskEntry.PRIORITY_HIGH;
        }
        return TaskContract.TaskEntry.PRIORITY_MEDIUM;
    }

    private void loadTaskForEdit() {
        Uri taskUri = ContentUris.withAppendedId(TaskContract.TaskEntry.CONTENT_URI, editingTaskId);
        try (Cursor cursor = getContentResolver().query(taskUri, null, null, null, null)) {
            if (cursor == null || !cursor.moveToFirst()) {
                Toast.makeText(this, R.string.task_not_found, Toast.LENGTH_SHORT).show();
                finish();
                return;
            }

            titleEditText.setText(cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_TITLE)));
            contentEditText.setText(cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_CONTENT)));

            deadlineTime = cursor.getLong(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_DEADLINE_TIME));
            remindTime = cursor.getLong(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_REMIND_TIME));
            editingCompleted = cursor.getInt(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_COMPLETED));
            editingReminded = cursor.getInt(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_REMINDED));
            editingCreatedAt = cursor.getLong(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_CREATED_AT));
            deadlineButton.setText(DateTimeUtil.formatDateTime(deadlineTime));
            remindTimeButton.setText(DateTimeUtil.formatDateTime(remindTime));

            int priority = cursor.getInt(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_PRIORITY));
            if (priority == TaskContract.TaskEntry.PRIORITY_LOW) {
                priorityRadioGroup.check(R.id.rbPriorityLow);
            } else if (priority == TaskContract.TaskEntry.PRIORITY_HIGH) {
                priorityRadioGroup.check(R.id.rbPriorityHigh);
            } else {
                priorityRadioGroup.check(R.id.rbPriorityMedium);
            }
        }
    }
}
