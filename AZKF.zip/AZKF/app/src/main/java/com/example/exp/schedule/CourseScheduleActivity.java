package com.example.exp.schedule;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.exp.R;
import com.example.exp.schedule.data.CourseRepository;
import com.example.exp.schedule.model.Course;

import java.util.ArrayList;
import java.util.List;

public class CourseScheduleActivity extends AppCompatActivity {
    private static final int MIN_WEEK = 1;
    private static final int MAX_WEEK = 25;
    private static final int SECTION_COUNT = 14;
    private static final int COLUMN_COUNT = 8;
    private static final int ROW_HEIGHT_DP = 58;
    private static final String[] ACTIVE_FILL_COLORS = {
            "#EDE9FE", "#DBEAFE", "#DCFCE7", "#FEF3C7", "#FFE4E6", "#CCFBF1"
    };
    private static final String[] ACTIVE_STROKE_COLORS = {
            "#C4B5FD", "#93C5FD", "#86EFAC", "#FCD34D", "#FDA4AF", "#5EEAD4"
    };
    private static final String[] WEEKDAY_LABELS = {
            "", "一", "二", "三", "四", "五", "六", "日"
    };
    private static final String[] SECTION_TIME_LABELS = {
            "",
            "1\n08:00\n08:45",
            "2\n08:50\n09:35",
            "3\n09:50\n10:35",
            "4\n10:40\n11:25",
            "5\n11:30\n12:15",
            "6\n13:30\n14:15",
            "7\n14:20\n15:05",
            "8\n15:20\n16:05",
            "9\n16:10\n16:55",
            "10\n18:30\n19:15",
            "11\n19:20\n20:05",
            "12\n20:10\n20:55",
            "13\n21:00\n21:45",
            "14\n21:50\n22:35"
    };

    private int currentWeek = 1;
    private TextView currentWeekTextView;
    private TextView emptyStateTextView;
    private Button previousWeekButton;
    private Button nextWeekButton;
    private CheckBox showInactiveCoursesCheckBox;
    private GridLayout courseGrid;
    private CourseRepository courseRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_course_schedule);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.courseScheduleRoot), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        findViewById(R.id.btnBackFromSchedule).setOnClickListener(v -> finish());
        findViewById(R.id.btnAddCourse).setOnClickListener(v ->
                startActivity(new Intent(this, CourseEditActivity.class)));
        findViewById(R.id.btnBistuImport).setOnClickListener(v ->
                startActivity(new Intent(this, BistuTeachingImportActivity.class)));
        findViewById(R.id.btnClearCourses).setOnClickListener(v -> confirmClearCourses());
        currentWeekTextView = findViewById(R.id.tvCurrentWeek);
        emptyStateTextView = findViewById(R.id.tvCourseEmptyState);
        previousWeekButton = findViewById(R.id.btnPreviousWeek);
        nextWeekButton = findViewById(R.id.btnNextWeek);
        showInactiveCoursesCheckBox = findViewById(R.id.cbShowInactiveCourses);
        courseGrid = findViewById(R.id.courseGrid);
        courseRepository = new CourseRepository(this);

        previousWeekButton.setOnClickListener(v -> changeWeek(-1));
        nextWeekButton.setOnClickListener(v -> changeWeek(1));
        showInactiveCoursesCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> renderSchedule());

        renderSchedule();
    }

    private void confirmClearCourses() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.clear_course_confirm_title)
                .setMessage(R.string.clear_course_confirm_message)
                .setPositiveButton(R.string.clear_course_confirm_positive, (dialog, which) -> {
                    int deleted = courseRepository.deleteAllCourses();
                    Toast.makeText(
                            this,
                            getString(R.string.clear_course_success, deleted),
                            Toast.LENGTH_SHORT
                    ).show();
                    renderSchedule();
                })
                .setNegativeButton(R.string.clear_course_confirm_negative, null)
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (courseRepository != null) {
            renderSchedule();
        }
    }

    private void changeWeek(int offset) {
        int newWeek = currentWeek + offset;
        if (newWeek < MIN_WEEK || newWeek > MAX_WEEK) {
            return;
        }
        currentWeek = newWeek;
        renderSchedule();
    }

    private void renderSchedule() {
        currentWeekTextView.setText(getString(R.string.current_week_label, currentWeek));
        previousWeekButton.setEnabled(currentWeek > MIN_WEEK);
        nextWeekButton.setEnabled(currentWeek < MAX_WEEK);
        boolean showInactive = showInactiveCoursesCheckBox.isChecked();
        List<Course> courses = showInactive
                ? courseRepository.queryAllCourses()
                : courseRepository.queryCoursesForWeek(currentWeek);
        int activeCourseCount = countActiveCourses(courses);
        updateEmptyState(activeCourseCount, courses.isEmpty(), showInactive);
        buildScheduleGrid(courses, showInactive);
    }

    private void buildScheduleGrid(List<Course> courses, boolean showInactive) {
        courseGrid.removeAllViews();
        courseGrid.setColumnCount(COLUMN_COUNT);
        courseGrid.setRowCount(SECTION_COUNT + 1);
        courseGrid.setUseDefaultMargins(false);
        courseGrid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);

        int leftColumnWidth = dp(42);
        int dayColumnWidth = calculateDayColumnWidth(leftColumnWidth);
        CourseBlock[][] blocks = new CourseBlock[SECTION_COUNT + 1][COLUMN_COUNT];
        mapCourses(courses, showInactive, blocks);

        for (int column = 0; column < COLUMN_COUNT; column++) {
            boolean firstColumn = column == 0;
            TextView cell = createCell(
                    WEEKDAY_LABELS[column],
                    firstColumn ? leftColumnWidth : dayColumnWidth,
                    dp(38),
                    "#E2E8F0",
                    "#CBD5E1",
                    true
            );
            addCell(cell, 0, column);
        }

        for (int section = 1; section <= SECTION_COUNT; section++) {
            TextView sectionCell = createCell(
                    SECTION_TIME_LABELS[section],
                    leftColumnWidth,
                    dp(ROW_HEIGHT_DP),
                    "#EEF2F7",
                    "#CBD5E1",
                    true
            );
            addCell(sectionCell, section, 0);

            for (int column = 1; column < COLUMN_COUNT; column++) {
                CourseBlock block = blocks[section][column];
                if (block != null) {
                    TextView courseCell = createCourseCell(block, dayColumnWidth, dp(ROW_HEIGHT_DP));
                    addCell(courseCell, section, column);
                    continue;
                }
                TextView emptyCell = createCell(
                        "",
                        dayColumnWidth,
                        dp(ROW_HEIGHT_DP),
                        "#FFFFFF",
                        "#E2E8F0",
                        false
                );
                addCell(emptyCell, section, column);
            }
        }
    }

    private int countActiveCourses(List<Course> courses) {
        int count = 0;
        for (Course course : courses) {
            if (course.isActiveInWeek(currentWeek)) {
                count++;
            }
        }
        return count;
    }

    private void updateEmptyState(int activeCourseCount, boolean noRenderedCourses, boolean showInactive) {
        if (activeCourseCount > 0) {
            emptyStateTextView.setVisibility(View.GONE);
            return;
        }
        emptyStateTextView.setVisibility(View.VISIBLE);
        if (showInactive && !noRenderedCourses) {
            emptyStateTextView.setText(R.string.course_schedule_inactive_only_message);
        } else {
            emptyStateTextView.setText(R.string.course_schedule_empty_message);
        }
    }

    private void mapCourses(List<Course> courses, boolean showInactive, CourseBlock[][] blocks) {
        for (Course course : courses) {
            boolean active = course.isActiveInWeek(currentWeek);
            if (!active && !showInactive) {
                continue;
            }
            int weekday = course.getWeekday();
            int start = course.getStartSection();
            int end = course.getEndSection();
            if (weekday < 1 || weekday > 7 || start < 1 || start > SECTION_COUNT) {
                continue;
            }
            end = Math.min(end, SECTION_COUNT);
            if (end < start) {
                continue;
            }

            for (int section = start; section <= end; section++) {
                CourseBlock block = blocks[section][weekday];
                if (block == null) {
                    block = new CourseBlock(weekday, section, section, active);
                    blocks[section][weekday] = block;
                } else {
                    block.hasActiveCourse = block.hasActiveCourse || active;
                }
                block.courses.add(course);
            }
        }
    }

    private TextView createCourseCell(CourseBlock block, int width, int height) {
        String fillColor;
        String strokeColor;
        String textColor;
        if (block.courses.size() > 1) {
            fillColor = "#FFF7ED";
            strokeColor = "#FDBA74";
            textColor = "#9A3412";
        } else if (!block.hasActiveCourse) {
            fillColor = "#F1F5F9";
            strokeColor = "#CBD5E1";
            textColor = "#94A3B8";
        } else {
            int colorIndex = Math.abs((int) block.courses.get(0).getId()) % ACTIVE_FILL_COLORS.length;
            fillColor = ACTIVE_FILL_COLORS[colorIndex];
            strokeColor = ACTIVE_STROKE_COLORS[colorIndex];
            textColor = "#334155";
        }

        TextView textView = createCell(
                buildCourseBlockText(block),
                width,
                height,
                fillColor,
                strokeColor,
                true
        );
        textView.setTextColor(Color.parseColor(textColor));
        textView.setTextSize(9);
        textView.setGravity(Gravity.CENTER);
        textView.setMaxLines(4);
        textView.setIncludeFontPadding(false);
        textView.setPadding(dp(1), dp(2), dp(1), dp(2));
        textView.setOnClickListener(v -> {
            Intent intent = new Intent(this, CourseEditActivity.class);
            intent.putExtra(CourseEditActivity.EXTRA_COURSE_ID, block.courses.get(0).getId());
            startActivity(intent);
        });
        return textView;
    }

    private String buildCourseBlockText(CourseBlock block) {
        StringBuilder text = new StringBuilder();
        if (block.courses.size() > 1) {
            text.append("多门").append(block.courses.size()).append("门");
            String rooms = buildRoomSummary(block.courses);
            if (!rooms.isEmpty()) {
                text.append("\n").append(rooms);
            }
            for (Course course : block.courses) {
                text.append("\n").append(compactCourseName(course.getCourseName(), 6));
            }
            return text.toString();
        }

        Course course = block.courses.get(0);
        if (!block.hasActiveCourse) {
            text.append("非本周\n");
        }
        if (course.getClassroom() != null && !course.getClassroom().isEmpty()) {
            text.append("@").append(course.getClassroom()).append("\n");
        }
        text.append(compactCourseName(course.getCourseName(), 10));
        return text.toString();
    }

    private String compactCourseName(String courseName, int maxLength) {
        if (courseName == null) {
            return "";
        }
        String compactName = courseName.replaceAll("\\[[^\\]]+\\]", "").trim();
        if (compactName.length() <= maxLength) {
            return compactName;
        }
        return compactName.substring(0, maxLength) + "…";
    }

    private String buildRoomSummary(List<Course> courses) {
        List<String> rooms = new ArrayList<>();
        for (Course course : courses) {
            String room = course.getClassroom();
            if (room == null || room.isEmpty() || rooms.contains(room)) {
                continue;
            }
            rooms.add(room);
            if (rooms.size() == 2) {
                break;
            }
        }
        if (rooms.isEmpty()) {
            return "";
        }
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < rooms.size(); i++) {
            if (i > 0) {
                text.append("/");
            }
            text.append("@").append(rooms.get(i));
        }
        return text.toString();
    }

    private int calculateDayColumnWidth(int leftColumnWidth) {
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        int horizontalContentPadding = dp(24);
        int availableWidth = metrics.widthPixels - horizontalContentPadding - leftColumnWidth;
        return Math.max(dp(38), availableWidth / 7);
    }

    private TextView createCell(String text, int width, int height, String fillColor,
                                String strokeColor, boolean bold) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setWidth(width);
        textView.setHeight(height);
        textView.setMinWidth(width);
        textView.setMinHeight(height);
        textView.setLayoutParams(new ViewGroup.LayoutParams(width, height));
        textView.setGravity(Gravity.CENTER);
        textView.setTextColor(Color.parseColor("#334155"));
        textView.setTextSize(11);
        textView.setPadding(dp(2), dp(3), dp(2), dp(3));
        if (bold) {
            textView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        }
        textView.setBackground(createCellBackground(fillColor, strokeColor));
        return textView;
    }

    private GradientDrawable createCellBackground(String fillColor, String strokeColor) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.parseColor(fillColor));
        drawable.setStroke(dp(1), Color.parseColor(strokeColor));
        return drawable;
    }

    private void addCell(TextView cell, int row, int column) {
        addCell(cell, row, column, 1);
    }

    private void addCell(TextView cell, int row, int column, int rowSpan) {
        ViewGroup.LayoutParams existingParams = cell.getLayoutParams();
        GridLayout.LayoutParams params = new GridLayout.LayoutParams(
                GridLayout.spec(row, rowSpan, GridLayout.FILL),
                GridLayout.spec(column, GridLayout.FILL)
        );
        params.width = existingParams == null ? ViewGroup.LayoutParams.WRAP_CONTENT : existingParams.width;
        params.height = existingParams == null ? ViewGroup.LayoutParams.WRAP_CONTENT : existingParams.height;
        params.setGravity(Gravity.FILL);
        courseGrid.addView(cell, params);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static class CourseBlock {
        private final int weekday;
        private final int startSection;
        private int endSection;
        private boolean hasActiveCourse;
        private final List<Course> courses = new ArrayList<>();

        private CourseBlock(int weekday, int startSection, int endSection, boolean hasActiveCourse) {
            this.weekday = weekday;
            this.startSection = startSection;
            this.endSection = endSection;
            this.hasActiveCourse = hasActiveCourse;
        }
    }
}
