package com.example.exp.schedule.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.exp.schedule.model.Course;

import java.util.ArrayList;
import java.util.List;

public class CourseRepository {
    private final CourseDatabaseHelper databaseHelper;

    public CourseRepository(Context context) {
        databaseHelper = new CourseDatabaseHelper(context.getApplicationContext());
    }

    public long insertCourse(Course course) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        return db.insert(CourseContract.CourseEntry.TABLE_NAME, null, toContentValues(course));
    }

    public int insertCoursesSkippingDuplicates(List<Course> courses) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        int inserted = 0;
        db.beginTransaction();
        try {
            for (Course course : courses) {
                if (isDuplicateCourse(db, course)) {
                    continue;
                }
                long id = db.insert(CourseContract.CourseEntry.TABLE_NAME, null, toContentValues(course));
                if (id > 0) {
                    inserted++;
                }
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return inserted;
    }

    public int updateCourse(Course course) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        return db.update(
                CourseContract.CourseEntry.TABLE_NAME,
                toContentValues(course),
                CourseContract.CourseEntry._ID + "=?",
                new String[]{String.valueOf(course.getId())}
        );
    }

    public int deleteCourse(long courseId) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        return db.delete(
                CourseContract.CourseEntry.TABLE_NAME,
                CourseContract.CourseEntry._ID + "=?",
                new String[]{String.valueOf(courseId)}
        );
    }

    public int deleteAllCourses() {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        return db.delete(CourseContract.CourseEntry.TABLE_NAME, null, null);
    }

    public List<Course> queryAllCourses() {
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        String sortOrder = CourseContract.CourseEntry.COLUMN_WEEKDAY + " ASC, "
                + CourseContract.CourseEntry.COLUMN_START_SECTION + " ASC";
        try (Cursor cursor = db.query(
                CourseContract.CourseEntry.TABLE_NAME,
                null,
                null,
                null,
                null,
                null,
                sortOrder
        )) {
            return readCourses(cursor);
        }
    }

    public Course queryCourseById(long courseId) {
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        try (Cursor cursor = db.query(
                CourseContract.CourseEntry.TABLE_NAME,
                null,
                CourseContract.CourseEntry._ID + "=?",
                new String[]{String.valueOf(courseId)},
                null,
                null,
                null
        )) {
            if (cursor.moveToFirst()) {
                return readCourse(cursor);
            }
            return null;
        }
    }

    public List<Course> queryCoursesForWeek(int week) {
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        String selection = CourseContract.CourseEntry.COLUMN_START_WEEK + "<=? AND "
                + CourseContract.CourseEntry.COLUMN_END_WEEK + ">=?";
        String[] selectionArgs = {String.valueOf(week), String.valueOf(week)};
        String sortOrder = CourseContract.CourseEntry.COLUMN_WEEKDAY + " ASC, "
                + CourseContract.CourseEntry.COLUMN_START_SECTION + " ASC";
        try (Cursor cursor = db.query(
                CourseContract.CourseEntry.TABLE_NAME,
                null,
                selection,
                selectionArgs,
                null,
                null,
                sortOrder
        )) {
            return readCourses(cursor);
        }
    }

    private ContentValues toContentValues(Course course) {
        ContentValues values = new ContentValues();
        values.put(CourseContract.CourseEntry.COLUMN_COURSE_NAME, course.getCourseName());
        values.put(CourseContract.CourseEntry.COLUMN_TEACHER, course.getTeacher());
        values.put(CourseContract.CourseEntry.COLUMN_CLASSROOM, course.getClassroom());
        values.put(CourseContract.CourseEntry.COLUMN_WEEKDAY, course.getWeekday());
        values.put(CourseContract.CourseEntry.COLUMN_START_SECTION, course.getStartSection());
        values.put(CourseContract.CourseEntry.COLUMN_END_SECTION, course.getEndSection());
        values.put(CourseContract.CourseEntry.COLUMN_START_WEEK, course.getStartWeek());
        values.put(CourseContract.CourseEntry.COLUMN_END_WEEK, course.getEndWeek());
        values.put(CourseContract.CourseEntry.COLUMN_NOTE, course.getNote());
        values.put(CourseContract.CourseEntry.COLUMN_CREATED_AT,
                course.getCreatedAt() == 0 ? System.currentTimeMillis() : course.getCreatedAt());
        return values;
    }

    private boolean isDuplicateCourse(SQLiteDatabase db, Course course) {
        String selection = CourseContract.CourseEntry.COLUMN_COURSE_NAME + "=? AND "
                + CourseContract.CourseEntry.COLUMN_CLASSROOM + "=? AND "
                + CourseContract.CourseEntry.COLUMN_WEEKDAY + "=? AND "
                + CourseContract.CourseEntry.COLUMN_START_SECTION + "=? AND "
                + CourseContract.CourseEntry.COLUMN_END_SECTION + "=? AND "
                + CourseContract.CourseEntry.COLUMN_START_WEEK + "=? AND "
                + CourseContract.CourseEntry.COLUMN_END_WEEK + "=?";
        String[] selectionArgs = {
                safeString(course.getCourseName()),
                safeString(course.getClassroom()),
                String.valueOf(course.getWeekday()),
                String.valueOf(course.getStartSection()),
                String.valueOf(course.getEndSection()),
                String.valueOf(course.getStartWeek()),
                String.valueOf(course.getEndWeek())
        };
        try (Cursor cursor = db.query(
                CourseContract.CourseEntry.TABLE_NAME,
                new String[]{CourseContract.CourseEntry._ID},
                selection,
                selectionArgs,
                null,
                null,
                null,
                "1"
        )) {
            return cursor.moveToFirst();
        }
    }

    private String safeString(String value) {
        return value == null ? "" : value;
    }

    private List<Course> readCourses(Cursor cursor) {
        List<Course> courses = new ArrayList<>();
        while (cursor.moveToNext()) {
            courses.add(readCourse(cursor));
        }
        return courses;
    }

    private Course readCourse(Cursor cursor) {
        Course course = new Course();
        course.setId(cursor.getLong(cursor.getColumnIndexOrThrow(CourseContract.CourseEntry._ID)));
        course.setCourseName(cursor.getString(cursor.getColumnIndexOrThrow(
                CourseContract.CourseEntry.COLUMN_COURSE_NAME)));
        course.setTeacher(cursor.getString(cursor.getColumnIndexOrThrow(
                CourseContract.CourseEntry.COLUMN_TEACHER)));
        course.setClassroom(cursor.getString(cursor.getColumnIndexOrThrow(
                CourseContract.CourseEntry.COLUMN_CLASSROOM)));
        course.setWeekday(cursor.getInt(cursor.getColumnIndexOrThrow(
                CourseContract.CourseEntry.COLUMN_WEEKDAY)));
        course.setStartSection(cursor.getInt(cursor.getColumnIndexOrThrow(
                CourseContract.CourseEntry.COLUMN_START_SECTION)));
        course.setEndSection(cursor.getInt(cursor.getColumnIndexOrThrow(
                CourseContract.CourseEntry.COLUMN_END_SECTION)));
        course.setStartWeek(cursor.getInt(cursor.getColumnIndexOrThrow(
                CourseContract.CourseEntry.COLUMN_START_WEEK)));
        course.setEndWeek(cursor.getInt(cursor.getColumnIndexOrThrow(
                CourseContract.CourseEntry.COLUMN_END_WEEK)));
        course.setNote(cursor.getString(cursor.getColumnIndexOrThrow(
                CourseContract.CourseEntry.COLUMN_NOTE)));
        course.setCreatedAt(cursor.getLong(cursor.getColumnIndexOrThrow(
                CourseContract.CourseEntry.COLUMN_CREATED_AT)));
        return course;
    }
}
