package com.example.exp.util;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.example.exp.R;
import com.example.exp.receiver.ReminderReceiver;

public final class ReminderUtil {
    public static final String ACTION_TASK_REMINDER = "com.example.exp.ACTION_TASK_REMINDER";
    public static final String EXTRA_TASK_ID = "task_id";

    private ReminderUtil() {
    }

    public static void scheduleReminder(Context context, long taskId, long remindTimeMillis) {
        if (taskId <= 0 || remindTimeMillis <= System.currentTimeMillis()) {
            return;
        }

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            Toast.makeText(context, R.string.reminder_schedule_failed, Toast.LENGTH_SHORT).show();
            return;
        }

        PendingIntent pendingIntent = createReminderPendingIntent(context, taskId);
        alarmManager.set(AlarmManager.RTC_WAKEUP, remindTimeMillis, pendingIntent);
    }

    public static void cancelReminder(Context context, long taskId) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null || taskId <= 0) {
            return;
        }

        PendingIntent pendingIntent = createReminderPendingIntent(context, taskId);
        alarmManager.cancel(pendingIntent);
    }

    private static PendingIntent createReminderPendingIntent(Context context, long taskId) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.setAction(ACTION_TASK_REMINDER);
        intent.putExtra(EXTRA_TASK_ID, taskId);

        int requestCode = (int) (taskId & 0x7fffffff);
        return PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }
}
