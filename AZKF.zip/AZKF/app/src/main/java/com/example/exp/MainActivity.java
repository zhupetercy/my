package com.example.exp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.exp.adapter.TaskAdapter;
import com.example.exp.data.TaskContract;
import com.example.exp.model.Task;
import com.example.exp.util.NetworkUtil;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_POST_NOTIFICATIONS = 1001;
    private static final int SORT_BY_DEADLINE = 0;
    private static final int SORT_BY_REMIND_TIME = 1;
    private static final int SORT_BY_PRIORITY = 2;

    private TaskAdapter taskAdapter;
    private View emptyStateLayout;
    private RecyclerView taskRecyclerView;
    private TextView dailyTipTextView;
    private int currentSortMode = SORT_BY_DEADLINE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        findViewById(R.id.btnBackFromTaskManager).setOnClickListener(v -> finish());

        Button addTaskButton = findViewById(R.id.btnAddTask);
        addTaskButton.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, AddTaskActivity.class)));

        dailyTipTextView = findViewById(R.id.tvDailyTip);
        emptyStateLayout = findViewById(R.id.emptyStateLayout);
        taskRecyclerView = findViewById(R.id.rvTaskList);
        taskAdapter = new TaskAdapter(task -> {
            Intent intent = new Intent(MainActivity.this, TaskDetailActivity.class);
            intent.putExtra(TaskDetailActivity.EXTRA_TASK_ID, task.getId());
            startActivity(intent);
        });
        taskRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        taskRecyclerView.setAdapter(taskAdapter);

        setupSortSpinner();
        requestNotificationPermissionIfNeeded();
        loadDailyTip();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadTasks();
    }

    private void loadTasks() {
        List<Task> tasks = new ArrayList<>();
        String sortOrder = buildSortOrder();

        try (Cursor cursor = getContentResolver().query(
                TaskContract.TaskEntry.CONTENT_URI,
                null,
                null,
                null,
                sortOrder
        )) {
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    tasks.add(readTaskFromCursor(cursor));
                }
            }
        }

        taskAdapter.submitList(tasks);
        boolean hasTasks = !tasks.isEmpty();
        taskRecyclerView.setVisibility(hasTasks ? View.VISIBLE : View.GONE);
        emptyStateLayout.setVisibility(hasTasks ? View.GONE : View.VISIBLE);
    }

    private Task readTaskFromCursor(Cursor cursor) {
        Task task = new Task();
        task.setId(cursor.getLong(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry._ID)));
        task.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_TITLE)));
        task.setContent(cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_CONTENT)));
        task.setDeadlineTime(cursor.getLong(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_DEADLINE_TIME)));
        task.setRemindTime(cursor.getLong(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_REMIND_TIME)));
        task.setPriority(cursor.getInt(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_PRIORITY)));
        task.setCompleted(cursor.getInt(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_COMPLETED)));
        task.setReminded(cursor.getInt(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_REMINDED)));
        task.setCreatedAt(cursor.getLong(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_CREATED_AT)));
        return task;
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            return;
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED) {
            return;
        }
        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.POST_NOTIFICATIONS},
                REQUEST_POST_NOTIFICATIONS
        );
    }

    private void loadDailyTip() {
        dailyTipTextView.setText(NetworkUtil.getLocalTip());
        NetworkUtil.fetchDailyTip(tip -> dailyTipTextView.setText(tip));
    }

    private void setupSortSpinner() {
        Spinner sortSpinner = findViewById(R.id.spTaskSort);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.task_sort_options,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sortSpinner.setAdapter(adapter);
        sortSpinner.setSelection(currentSortMode);
        sortSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (currentSortMode == position) {
                    return;
                }
                currentSortMode = position;
                loadTasks();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private String buildSortOrder() {
        String deadline = TaskContract.TaskEntry.COLUMN_DEADLINE_TIME;
        String remindTime = TaskContract.TaskEntry.COLUMN_REMIND_TIME;
        String priority = TaskContract.TaskEntry.COLUMN_PRIORITY;

        if (currentSortMode == SORT_BY_REMIND_TIME) {
            return remindTime + " ASC, "
                    + deadline + " ASC, "
                    + priority + " DESC";
        }
        if (currentSortMode == SORT_BY_PRIORITY) {
            return priority + " DESC, "
                    + deadline + " ASC, "
                    + remindTime + " ASC";
        }
        return deadline + " ASC, "
                + priority + " DESC, "
                + remindTime + " ASC";
    }
}
