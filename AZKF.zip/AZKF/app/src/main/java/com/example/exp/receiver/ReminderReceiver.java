package com.example.exp.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.example.exp.service.ReminderService;
import com.example.exp.util.ReminderUtil;

public class ReminderReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        long taskId = intent.getLongExtra(ReminderUtil.EXTRA_TASK_ID, -1);
        if (taskId <= 0) {
            return;
        }

        Intent serviceIntent = new Intent(context, ReminderService.class);
        serviceIntent.putExtra(ReminderUtil.EXTRA_TASK_ID, taskId);
        context.startService(serviceIntent);
    }
}
