package com.example.exp.data;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

public class TaskProvider extends ContentProvider {
    private static final int TASKS = 1;
    private static final int TASK_ID = 2;

    private static final UriMatcher URI_MATCHER = new UriMatcher(UriMatcher.NO_MATCH);

    static {
        URI_MATCHER.addURI(TaskContract.AUTHORITY, TaskContract.PATH_TASKS, TASKS);
        URI_MATCHER.addURI(TaskContract.AUTHORITY, TaskContract.PATH_TASKS + "/#", TASK_ID);
    }

    private TaskDatabaseHelper databaseHelper;

    @Override
    public boolean onCreate() {
        databaseHelper = new TaskDatabaseHelper(getContext());
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
                        String sortOrder) {
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        Cursor cursor;

        switch (URI_MATCHER.match(uri)) {
            case TASKS:
                cursor = db.query(
                        TaskContract.TaskEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder
                );
                break;
            case TASK_ID:
                String idSelection = TaskContract.TaskEntry._ID + "=?";
                String[] idSelectionArgs = new String[]{String.valueOf(ContentUris.parseId(uri))};
                cursor = db.query(
                        TaskContract.TaskEntry.TABLE_NAME,
                        projection,
                        idSelection,
                        idSelectionArgs,
                        null,
                        null,
                        sortOrder
                );
                break;
            default:
                throw new IllegalArgumentException("Unknown URI: " + uri);
        }

        if (getContext() != null) {
            cursor.setNotificationUri(getContext().getContentResolver(), uri);
        }
        return cursor;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        if (URI_MATCHER.match(uri) != TASKS) {
            throw new IllegalArgumentException("Insert is not supported for URI: " + uri);
        }

        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        long id = db.insertOrThrow(TaskContract.TaskEntry.TABLE_NAME, null, values);
        Uri newUri = ContentUris.withAppendedId(TaskContract.TaskEntry.CONTENT_URI, id);
        notifyChange(newUri);
        return newUri;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        int rowsUpdated;

        switch (URI_MATCHER.match(uri)) {
            case TASKS:
                rowsUpdated = db.update(
                        TaskContract.TaskEntry.TABLE_NAME,
                        values,
                        selection,
                        selectionArgs
                );
                break;
            case TASK_ID:
                String idSelection = appendIdSelection(selection);
                String[] idSelectionArgs = appendIdSelectionArgs(uri, selectionArgs);
                rowsUpdated = db.update(
                        TaskContract.TaskEntry.TABLE_NAME,
                        values,
                        idSelection,
                        idSelectionArgs
                );
                break;
            default:
                throw new IllegalArgumentException("Update is not supported for URI: " + uri);
        }

        if (rowsUpdated > 0) {
            notifyChange(uri);
        }
        return rowsUpdated;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        int rowsDeleted;

        switch (URI_MATCHER.match(uri)) {
            case TASKS:
                rowsDeleted = db.delete(
                        TaskContract.TaskEntry.TABLE_NAME,
                        selection,
                        selectionArgs
                );
                break;
            case TASK_ID:
                String idSelection = appendIdSelection(selection);
                String[] idSelectionArgs = appendIdSelectionArgs(uri, selectionArgs);
                rowsDeleted = db.delete(
                        TaskContract.TaskEntry.TABLE_NAME,
                        idSelection,
                        idSelectionArgs
                );
                break;
            default:
                throw new IllegalArgumentException("Delete is not supported for URI: " + uri);
        }

        if (rowsDeleted > 0) {
            notifyChange(uri);
        }
        return rowsDeleted;
    }

    @Override
    public String getType(Uri uri) {
        switch (URI_MATCHER.match(uri)) {
            case TASKS:
                return "vnd.android.cursor.dir/vnd." + TaskContract.AUTHORITY + ".tasks";
            case TASK_ID:
                return "vnd.android.cursor.item/vnd." + TaskContract.AUTHORITY + ".tasks";
            default:
                throw new IllegalArgumentException("Unknown URI: " + uri);
        }
    }

    private void notifyChange(Uri uri) {
        if (getContext() != null) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
    }

    private String appendIdSelection(String selection) {
        String idSelection = TaskContract.TaskEntry._ID + "=?";
        if (selection == null || selection.trim().isEmpty()) {
            return idSelection;
        }
        return idSelection + " AND (" + selection + ")";
    }

    private String[] appendIdSelectionArgs(Uri uri, String[] selectionArgs) {
        String id = String.valueOf(ContentUris.parseId(uri));
        if (selectionArgs == null || selectionArgs.length == 0) {
            return new String[]{id};
        }

        String[] result = new String[selectionArgs.length + 1];
        result[0] = id;
        System.arraycopy(selectionArgs, 0, result, 1, selectionArgs.length);
        return result;
    }
}
