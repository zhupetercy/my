package com.example.exp.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class TaskDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "study_reminder.db";
    private static final int DATABASE_VERSION = 1;

    public TaskDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 任务表保存学习任务、时间、状态和提醒标记。
        String createTaskTable = "CREATE TABLE " + TaskContract.TaskEntry.TABLE_NAME + " ("
                + TaskContract.TaskEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + TaskContract.TaskEntry.COLUMN_TITLE + " TEXT NOT NULL, "
                + TaskContract.TaskEntry.COLUMN_CONTENT + " TEXT, "
                + TaskContract.TaskEntry.COLUMN_DEADLINE_TIME + " INTEGER, "
                + TaskContract.TaskEntry.COLUMN_REMIND_TIME + " INTEGER, "
                + TaskContract.TaskEntry.COLUMN_PRIORITY + " INTEGER DEFAULT "
                + TaskContract.TaskEntry.PRIORITY_MEDIUM + ", "
                + TaskContract.TaskEntry.COLUMN_COMPLETED + " INTEGER DEFAULT "
                + TaskContract.TaskEntry.STATUS_UNCOMPLETED + ", "
                + TaskContract.TaskEntry.COLUMN_REMINDED + " INTEGER DEFAULT "
                + TaskContract.TaskEntry.REMINDED_NO + ", "
                + TaskContract.TaskEntry.COLUMN_CREATED_AT + " INTEGER"
                + ");";

        db.execSQL(createTaskTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TaskContract.TaskEntry.TABLE_NAME);
        onCreate(db);
    }
}
