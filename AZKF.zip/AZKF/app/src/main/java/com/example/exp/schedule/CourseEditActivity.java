package com.example.exp.schedule;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.exp.R;
import com.example.exp.schedule.data.CourseRepository;
import com.example.exp.schedule.model.Course;

public class CourseEditActivity extends AppCompatActivity {
    public static final String EXTRA_COURSE_ID = "course_id";

    private EditText courseNameEditText;
    private EditText teacherEditText;
    private EditText classroomEditText;
    private EditText noteEditText;
    private Spinner weekdaySpinner;
    private Spinner startSectionSpinner;
    private Spinner endSectionSpinner;
    private Spinner startWeekSpinner;
    private Spinner endWeekSpinner;
    private Button deleteButton;

    private CourseRepository courseRepository;
    private long editingCourseId = -1;
    private long editingCreatedAt = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_course_edit);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.courseEditRoot), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        courseRepository = new CourseRepository(this);
        bindViews();
        setupSpinners();

        ImageButton backButton = findViewById(R.id.btnBackFromCourseEdit);
        backButton.setOnClickListener(v -> finish());

        Button saveButton = findViewById(R.id.btnSaveCourse);
        saveButton.setOnClickListener(v -> saveCourse());

        deleteButton.setOnClickListener(v -> deleteCourse());

        editingCourseId = getIntent().getLongExtra(EXTRA_COURSE_ID, -1);
        if (editingCourseId > 0) {
            ((TextView) findViewById(R.id.tvCourseEditTitle)).setText(R.string.edit_course_title);
            deleteButton.setVisibility(View.VISIBLE);
            loadCourseForEdit();
        } else {
            deleteButton.setVisibility(View.GONE);
        }
    }

    private void bindViews() {
        courseNameEditText = findViewById(R.id.etCourseName);
        teacherEditText = findViewById(R.id.etCourseTeacher);
        classroomEditText = findViewById(R.id.etCourseClassroom);
        noteEditText = findViewById(R.id.etCourseNote);
        weekdaySpinner = findViewById(R.id.spCourseWeekday);
        startSectionSpinner = findViewById(R.id.spStartSection);
        endSectionSpinner = findViewById(R.id.spEndSection);
        startWeekSpinner = findViewById(R.id.spStartWeek);
        endWeekSpinner = findViewById(R.id.spEndWeek);
        deleteButton = findViewById(R.id.btnDeleteCourse);
    }

    private void setupSpinners() {
        setupSpinner(weekdaySpinner, new String[]{"周一", "周二", "周三", "周四", "周五", "周六", "周日"});
        setupSpinner(startSectionSpinner, buildNumberLabels(1, 14, "第", "节"));
        setupSpinner(endSectionSpinner, buildNumberLabels(1, 14, "第", "节"));
        setupSpinner(startWeekSpinner, buildNumberLabels(1, 25, "第", "周"));
        setupSpinner(endWeekSpinner, buildNumberLabels(1, 25, "第", "周"));

        endSectionSpinner.setSelection(1);
        endWeekSpinner.setSelection(15);
    }

    private void setupSpinner(Spinner spinner, String[] labels) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                labels
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    private String[] buildNumberLabels(int start, int end, String prefix, String suffix) {
        String[] labels = new String[end - start + 1];
        for (int i = start; i <= end; i++) {
            labels[i - start] = prefix + i + suffix;
        }
        return labels;
    }

    private void saveCourse() {
        String courseName = courseNameEditText.getText().toString().trim();
        if (courseName.isEmpty()) {
            Toast.makeText(this, R.string.please_input_course_name, Toast.LENGTH_SHORT).show();
            return;
        }

        int weekday = weekdaySpinner.getSelectedItemPosition() + 1;
        int startSection = startSectionSpinner.getSelectedItemPosition() + 1;
        int endSection = endSectionSpinner.getSelectedItemPosition() + 1;
        int startWeek = startWeekSpinner.getSelectedItemPosition() + 1;
        int endWeek = endWeekSpinner.getSelectedItemPosition() + 1;

        if (endSection < startSection) {
            Toast.makeText(this, R.string.course_section_invalid, Toast.LENGTH_SHORT).show();
            return;
        }
        if (endWeek < startWeek) {
            Toast.makeText(this, R.string.course_week_invalid, Toast.LENGTH_SHORT).show();
            return;
        }

        Course course = new Course();
        course.setId(editingCourseId);
        course.setCourseName(courseName);
        course.setTeacher(teacherEditText.getText().toString().trim());
        course.setClassroom(classroomEditText.getText().toString().trim());
        course.setWeekday(weekday);
        course.setStartSection(startSection);
        course.setEndSection(endSection);
        course.setStartWeek(startWeek);
        course.setEndWeek(endWeek);
        course.setNote(noteEditText.getText().toString().trim());
        course.setCreatedAt(editingCreatedAt);

        if (editingCourseId > 0) {
            int updated = courseRepository.updateCourse(course);
            if (updated <= 0) {
                Toast.makeText(this, R.string.course_update_failed, Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(this, R.string.course_update_success, Toast.LENGTH_SHORT).show();
        } else {
            long newId = courseRepository.insertCourse(course);
            if (newId <= 0) {
                Toast.makeText(this, R.string.course_save_failed, Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(this, R.string.course_save_success, Toast.LENGTH_SHORT).show();
        }

        finish();
    }

    private void deleteCourse() {
        if (editingCourseId <= 0) {
            return;
        }
        int deleted = courseRepository.deleteCourse(editingCourseId);
        if (deleted <= 0) {
            Toast.makeText(this, R.string.course_delete_failed, Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, R.string.course_delete_success, Toast.LENGTH_SHORT).show();
        finish();
    }

    private void loadCourseForEdit() {
        Course course = courseRepository.queryCourseById(editingCourseId);
        if (course == null) {
            Toast.makeText(this, R.string.course_not_found, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        courseNameEditText.setText(course.getCourseName());
        teacherEditText.setText(course.getTeacher());
        classroomEditText.setText(course.getClassroom());
        noteEditText.setText(course.getNote());
        editingCreatedAt = course.getCreatedAt();

        weekdaySpinner.setSelection(course.getWeekday() - 1);
        startSectionSpinner.setSelection(course.getStartSection() - 1);
        endSectionSpinner.setSelection(course.getEndSection() - 1);
        startWeekSpinner.setSelection(course.getStartWeek() - 1);
        endWeekSpinner.setSelection(course.getEndWeek() - 1);
    }
}
