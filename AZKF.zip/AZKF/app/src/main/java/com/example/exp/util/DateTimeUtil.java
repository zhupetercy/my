package com.example.exp.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class DateTimeUtil {
    private static final String DISPLAY_PATTERN = "yyyy-MM-dd HH:mm";

    private DateTimeUtil() {
    }

    public static String formatDateTime(long timeMillis) {
        if (timeMillis <= 0) {
            return "";
        }
        SimpleDateFormat format = new SimpleDateFormat(DISPLAY_PATTERN, Locale.CHINA);
        return format.format(new Date(timeMillis));
    }
}
