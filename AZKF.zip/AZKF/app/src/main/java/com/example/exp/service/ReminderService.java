package com.example.exp.service;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.example.exp.R;
import com.example.exp.TaskDetailActivity;
import com.example.exp.data.TaskContract;
import com.example.exp.util.ReminderUtil;

public class ReminderService extends Service {
    private static final String CHANNEL_ID = "study_reminder_channel";

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        long taskId = intent == null ? -1 : intent.getLongExtra(ReminderUtil.EXTRA_TASK_ID, -1);
        if (taskId > 0) {
            handleReminder(taskId);
        }
        stopSelf(startId);
        return START_NOT_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void handleReminder(long taskId) {
        Uri taskUri = ContentUris.withAppendedId(TaskContract.TaskEntry.CONTENT_URI, taskId);
        try (Cursor cursor = getContentResolver().query(taskUri, null, null, null, null)) {
            if (cursor == null || !cursor.moveToFirst()) {
                return;
            }

            int completed = cursor.getInt(cursor.getColumnIndexOrThrow(
                    TaskContract.TaskEntry.COLUMN_COMPLETED));
            if (completed == TaskContract.TaskEntry.STATUS_COMPLETED) {
                return;
            }

            String title = cursor.getString(cursor.getColumnIndexOrThrow(
                    TaskContract.TaskEntry.COLUMN_TITLE));
            if (showNotification(taskId, title)) {
                markReminded(taskUri);
            }
        }
    }

    private boolean showNotification(long taskId, String taskTitle) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return false;
        }

        createNotificationChannel();

        Intent detailIntent = new Intent(this, TaskDetailActivity.class);
        detailIntent.putExtra(TaskDetailActivity.EXTRA_TASK_ID, taskId);
        detailIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent contentIntent = PendingIntent.getActivity(
                this,
                (int) (taskId & 0x7fffffff),
                detailIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(getString(R.string.notification_title))
                .setContentText(getString(R.string.notification_content, taskTitle))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setDefaults(NotificationCompat.DEFAULT_SOUND)
                .setAutoCancel(true)
                .setContentIntent(contentIntent);

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.notify((int) (taskId & 0x7fffffff), builder.build());
            return true;
        }
        return false;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return;
        }

        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_HIGH
        );
        channel.setDescription(getString(R.string.notification_channel_description));

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void markReminded(Uri taskUri) {
        ContentValues values = new ContentValues();
        values.put(TaskContract.TaskEntry.COLUMN_REMINDED, TaskContract.TaskEntry.REMINDED_YES);
        getContentResolver().update(taskUri, values, null, null);
    }
}
