package com.example.exp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.exp.schedule.CourseScheduleActivity;

public class NavigationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_navigation);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.navigationRoot), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button taskButton = findViewById(R.id.btnOpenTaskManager);
        Button scheduleButton = findViewById(R.id.btnOpenCourseSchedule);

        taskButton.setOnClickListener(v ->
                startActivity(new Intent(NavigationActivity.this, MainActivity.class)));
        scheduleButton.setOnClickListener(v ->
                startActivity(new Intent(NavigationActivity.this, CourseScheduleActivity.class)));
    }
}
