package com.example.exp.util;

import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;

public final class NetworkUtil {
    private static final String DAILY_TIP_URL = "https://v1.hitokoto.cn/?encode=text";
    private static final int CONNECT_TIMEOUT_MS = 3000;
    private static final int READ_TIMEOUT_MS = 3000;

    private static final String[] LOCAL_TIPS = {
            "今日提示：先完成最重要的一件事。",
            "今日提示：把大任务拆成小步骤。",
            "今日提示：保持专注，减少频繁切换。",
            "今日提示：复习比临时突击更可靠。"
    };

    private NetworkUtil() {
    }

    public interface DailyTipCallback {
        void onTipLoaded(String tip);
    }

    public static void fetchDailyTip(DailyTipCallback callback) {
        new Thread(() -> {
            String tip = fetchTipFromNetwork();
            if (tip == null || tip.trim().isEmpty()) {
                tip = getLocalTip();
            } else {
                tip = "今日提示：" + tip.trim();
            }

            String finalTip = tip;
            new Handler(Looper.getMainLooper()).post(() -> callback.onTipLoaded(finalTip));
        }).start();
    }

    public static String getLocalTip() {
        int day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR);
        return LOCAL_TIPS[day % LOCAL_TIPS.length];
    }

    private static String fetchTipFromNetwork() {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(DAILY_TIP_URL);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);

            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                return null;
            }

            try (InputStream inputStream = connection.getInputStream();
                 BufferedReader reader = new BufferedReader(new InputStreamReader(
                         inputStream, StandardCharsets.UTF_8))) {
                StringBuilder builder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    builder.append(line);
                }
                return builder.toString();
            }
        } catch (Exception ignored) {
            return null;
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }
}
