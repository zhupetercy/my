package com.example.exp.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.exp.R;
import com.example.exp.data.TaskContract;
import com.example.exp.model.Task;
import com.example.exp.util.DateTimeUtil;

import java.util.ArrayList;
import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {
    public interface OnTaskClickListener {
        void onTaskClick(Task task);
    }

    private final List<Task> tasks = new ArrayList<>();
    private final OnTaskClickListener listener;

    public TaskAdapter(OnTaskClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_task, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = tasks.get(position);
        holder.bind(task, listener);
    }

    @Override
    public int getItemCount() {
        return tasks.size();
    }

    public void submitList(List<Task> newTasks) {
        tasks.clear();
        tasks.addAll(newTasks);
        notifyDataSetChanged();
    }

    static class TaskViewHolder extends RecyclerView.ViewHolder {
        private final TextView titleTextView;
        private final TextView deadlineTextView;
        private final TextView priorityTextView;
        private final TextView statusTextView;

        TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.tvTaskTitle);
            deadlineTextView = itemView.findViewById(R.id.tvTaskDeadline);
            priorityTextView = itemView.findViewById(R.id.tvTaskPriority);
            statusTextView = itemView.findViewById(R.id.tvTaskStatus);
        }

        void bind(Task task, OnTaskClickListener listener) {
            titleTextView.setText(task.getTitle());
            String deadline = DateTimeUtil.formatDateTime(task.getDeadlineTime());
            deadlineTextView.setText(itemView.getContext()
                    .getString(R.string.deadline_label, deadline));
            priorityTextView.setText(getPriorityText(task.getPriority()));

            boolean completed = task.getCompleted() == TaskContract.TaskEntry.STATUS_COMPLETED;
            statusTextView.setText(completed
                    ? R.string.status_completed
                    : R.string.status_uncompleted);
            itemView.setAlpha(completed ? 0.62f : 1f);
            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onTaskClick(task);
                }
            });
        }

        private String getPriorityText(int priority) {
            if (priority == TaskContract.TaskEntry.PRIORITY_LOW) {
                return itemView.getContext().getString(R.string.priority_low);
            }
            if (priority == TaskContract.TaskEntry.PRIORITY_HIGH) {
                return itemView.getContext().getString(R.string.priority_high);
            }
            return itemView.getContext().getString(R.string.priority_medium);
        }
    }
}
