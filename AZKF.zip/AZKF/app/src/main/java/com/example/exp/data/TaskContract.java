package com.example.exp.data;

import android.net.Uri;
import android.provider.BaseColumns;

public final class TaskContract {
    public static final String AUTHORITY = "com.example.exp.provider";
    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + AUTHORITY);
    public static final String PATH_TASKS = "tasks";

    private TaskContract() {
    }

    public static final class TaskEntry implements BaseColumns {
        public static final Uri CONTENT_URI =
                BASE_CONTENT_URI.buildUpon().appendPath(PATH_TASKS).build();

        public static final String TABLE_NAME = "task";

        public static final String COLUMN_TITLE = "title";
        public static final String COLUMN_CONTENT = "content";
        public static final String COLUMN_DEADLINE_TIME = "deadline_time";
        public static final String COLUMN_REMIND_TIME = "remind_time";
        public static final String COLUMN_PRIORITY = "priority";
        public static final String COLUMN_COMPLETED = "completed";
        public static final String COLUMN_REMINDED = "reminded";
        public static final String COLUMN_CREATED_AT = "created_at";

        public static final int PRIORITY_LOW = 1;
        public static final int PRIORITY_MEDIUM = 2;
        public static final int PRIORITY_HIGH = 3;

        public static final int STATUS_UNCOMPLETED = 0;
        public static final int STATUS_COMPLETED = 1;

        public static final int REMINDED_NO = 0;
        public static final int REMINDED_YES = 1;

        private TaskEntry() {
        }
    }
}
