package com.example.exp.schedule.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class CourseDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "course_schedule.db";
    private static final int DATABASE_VERSION = 1;

    public CourseDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 课程表数据独立存储，避免影响已有学习任务数据库。
        String createCourseTable = "CREATE TABLE " + CourseContract.CourseEntry.TABLE_NAME + " ("
                + CourseContract.CourseEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + CourseContract.CourseEntry.COLUMN_COURSE_NAME + " TEXT NOT NULL, "
                + CourseContract.CourseEntry.COLUMN_TEACHER + " TEXT, "
                + CourseContract.CourseEntry.COLUMN_CLASSROOM + " TEXT, "
                + CourseContract.CourseEntry.COLUMN_WEEKDAY + " INTEGER NOT NULL, "
                + CourseContract.CourseEntry.COLUMN_START_SECTION + " INTEGER NOT NULL, "
                + CourseContract.CourseEntry.COLUMN_END_SECTION + " INTEGER NOT NULL, "
                + CourseContract.CourseEntry.COLUMN_START_WEEK + " INTEGER NOT NULL, "
                + CourseContract.CourseEntry.COLUMN_END_WEEK + " INTEGER NOT NULL, "
                + CourseContract.CourseEntry.COLUMN_NOTE + " TEXT, "
                + CourseContract.CourseEntry.COLUMN_CREATED_AT + " INTEGER"
                + ");";

        db.execSQL(createCourseTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + CourseContract.CourseEntry.TABLE_NAME);
        onCreate(db);
    }
}
