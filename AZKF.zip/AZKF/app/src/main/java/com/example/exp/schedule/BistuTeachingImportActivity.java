package com.example.exp.schedule;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.exp.R;
import com.example.exp.schedule.data.BistuCoursePageParser;
import com.example.exp.schedule.data.CourseRepository;
import com.example.exp.schedule.model.Course;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BistuTeachingImportActivity extends AppCompatActivity {
    private static final String DEFAULT_PLATFORM_URL = "https://jwxt.bistu.edu.cn/";
    private static final String EXTRACT_SCRIPT =
            "(function(){"
                    + "var out=[];"
                    + "function safeText(el){return el&&el.innerText?el.innerText.trim():'';}"
                    + "function visible(el){if(!el){return false;}var r=el.getBoundingClientRect();var s=getComputedStyle(el);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden';}"
                    + "function hasClass(el,name){return (' '+(el.className||'')+' ').indexOf(' '+name+' ')>=0;}"
                    + "function weekdayOf(text){"
                    + " text=(text||'').replace(/\\s+/g,'');"
                    + " if(text==='\\u661f\\u671f\\u4e00'||text==='\\u5468\\u4e00'||text==='\\u4e00'){return 1;}"
                    + " if(text==='\\u661f\\u671f\\u4e8c'||text==='\\u5468\\u4e8c'||text==='\\u4e8c'){return 2;}"
                    + " if(text==='\\u661f\\u671f\\u4e09'||text==='\\u5468\\u4e09'||text==='\\u4e09'){return 3;}"
                    + " if(text==='\\u661f\\u671f\\u56db'||text==='\\u5468\\u56db'||text==='\\u56db'){return 4;}"
                    + " if(text==='\\u661f\\u671f\\u4e94'||text==='\\u5468\\u4e94'||text==='\\u4e94'){return 5;}"
                    + " if(text==='\\u661f\\u671f\\u516d'||text==='\\u5468\\u516d'||text==='\\u516d'){return 6;}"
                    + " if(text==='\\u661f\\u671f\\u65e5'||text==='\\u5468\\u65e5'||text==='\\u661f\\u671f\\u5929'||text==='\\u5468\\u5929'||text==='\\u65e5'||text==='\\u5929'){return 7;}"
                    + " return 0;"
                    + "}"
                    + "function collect(doc,label){"
                    + " if(!doc||!doc.body){return;}"
                    + " out.push('[[FRAME '+label+']]');"
                    + " out.push('[[URL]]\\n'+(doc.location?doc.location.href:''));"
                    + " var termRoot=doc.querySelector('.kbappKbRoot,main,article')||doc.body;"
                    + " var termText=safeText(termRoot);"
                    + " var termMatch=termText.match(/20\\d{2}-20\\d{2}\\u5b66\\u5e74\\s*(?:\\u7b2c[\\u4e00\\u4e8c\\u4e09\\u56db]\\u5b66\\u671f|\\u5c0f\\u5b66\\u671f)/);"
                    + " if(termMatch){out.push('[[TERM]]\\n'+termMatch[0]);}"
                    + " var headerNodes=Array.prototype.slice.call(doc.querySelectorAll('.timetable-header,th,td,div,span'));"
                    + " var headerCandidates=[];"
                    + " for(var i=0;i<headerNodes.length;i++){"
                    + "  var ht=safeText(headerNodes[i]);"
                    + "  var wd=weekdayOf(ht);"
                    + "  if(wd>0&&visible(headerNodes[i])){var hr=headerNodes[i].getBoundingClientRect();headerCandidates.push({weekday:wd,x:hr.x+hr.width/2,y:hr.y,text:ht});}"
                    + " }"
                    + " headerCandidates.sort(function(a,b){return a.y===b.y?a.x-b.x:a.y-b.y;});"
                    + " var headers=[];"
                    + " for(var h=0;h<headerCandidates.length;h++){"
                    + "  var item=headerCandidates[h];"
                    + "  var duplicate=false;"
                    + "  for(var j=0;j<headers.length;j++){if(headers[j].weekday===item.weekday&&Math.abs(headers[j].x-item.x)<20){duplicate=true;break;}}"
                    + "  if(!duplicate){headers.push(item);out.push('[[HEADER weekday='+item.weekday+' x='+Math.round(item.x)+']]\\n'+item.text);}"
                    + " }"
                    + " function nearestWeekday(cx){var best=null,dist=999999;for(var k=0;k<headers.length;k++){var d=Math.abs(headers[k].x-cx);if(d<dist){best=headers[k];dist=d;}}return best?best.weekday:-1;}"
                    + " var courseNodes=Array.prototype.slice.call(doc.querySelectorAll('.timetable-course-item,[class*=\"kbappTimetableCourseRenderCourseItem\"]'));"
                    + " var seen={};"
                    + " var courseCount=0;"
                    + " for(var c=0;c<courseNodes.length&&courseCount<800;c++){"
                    + "  var el=courseNodes[c];"
                    + "  if(!visible(el)){continue;}"
                    + "  var className=el.className||'';"
                    + "  if(!hasClass(el,'timetable-course-item')&&className.indexOf('kbappTimetableCourseRenderCourseItem')<0){continue;}"
                    + "  var text=safeText(el);"
                    + "  if(!/\\[[A-Za-z0-9_-]+\\]/.test(text)){continue;}"
                    + "  var childCourse=el.querySelector('.timetable-course-item,[class*=\"kbappTimetableCourseRenderCourseItem\"]');"
                    + "  if(childCourse&&childCourse!==el){continue;}"
                    + "  var r=el.getBoundingClientRect();"
                    + "  var weekday=nearestWeekday(r.x+r.width/2);"
                    + "  if(weekday<1){continue;}"
                    + "  var key=weekday+'|'+Math.round(r.x)+'|'+Math.round(r.y)+'|'+text;"
                    + "  if(seen[key]){continue;}"
                    + "  seen[key]=true;"
                    + "  out.push('[[VISIBLE_COURSE weekday='+weekday+' x='+Math.round(r.x)+' y='+Math.round(r.y)+' w='+Math.round(r.width)+' h='+Math.round(r.height)+']]\\n'+text);"
                    + "  courseCount++;"
                    + " }"
                    + " var candidateNodes=Array.prototype.slice.call(doc.querySelectorAll('div,span,li,p,a'));"
                    + " var candidateAdded=0;"
                    + " for(var n=0;n<candidateNodes.length&&candidateAdded<30;n++){"
                    + "  var tx=safeText(candidateNodes[n]);"
                    + "  if(tx&&/\\[[A-Za-z0-9_-]+\\]/.test(tx)&&visible(candidateNodes[n])){var nr=candidateNodes[n].getBoundingClientRect();out.push('[[CANDIDATE x='+Math.round(nr.x)+' y='+Math.round(nr.y)+' w='+Math.round(nr.width)+' h='+Math.round(nr.height)+' len='+tx.length+']]\\n'+tx);candidateAdded++;}"
                    + " }"
                    + "}"
                    + "collect(document,'top');"
                    + "var frames=document.querySelectorAll('iframe,frame');"
                    + "for(var f=0;f<frames.length;f++){try{collect(frames[f].contentDocument||frames[f].contentWindow.document,'iframe'+f);}catch(e){out.push('[[IFRAME_UNREADABLE '+f+']] '+(frames[f].src||''));}}"
                    + "return out.join('\\n');"
                    + "})();";

    private WebView webView;
    private TextView debugInfoTextView;
    private CourseRepository courseRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bistu_teaching_import);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.bistuImportRoot), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        courseRepository = new CourseRepository(this);
        webView = findViewById(R.id.webBistuPlatform);
        debugInfoTextView = findViewById(R.id.tvBistuDebugInfo);

        setupWebView();

        findViewById(R.id.btnBackFromBistuImport).setOnClickListener(v -> finish());
        findViewById(R.id.btnLoadBistuPlatform).setOnClickListener(v -> refreshPlatform());
        findViewById(R.id.btnParseBistuSchedule).setOnClickListener(v -> parseCurrentPage());

        loadPlatform();
    }

    @SuppressWarnings("deprecation")
    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setSaveFormData(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setGeolocationEnabled(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
            webView.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        }
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    Toast.makeText(
                            BistuTeachingImportActivity.this,
                            R.string.bistu_page_load_failed,
                            Toast.LENGTH_LONG
                    ).show();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        clearTeachingWebViewData();
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    private void clearTeachingWebViewData() {
        if (webView != null) {
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.clearHistory();
            webView.clearCache(true);
            webView.clearFormData();
            webView.destroy();
            webView = null;
        }
        WebStorage.getInstance().deleteAllData();
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.removeSessionCookies(null);
        cookieManager.removeAllCookies(null);
        cookieManager.flush();
    }

    private void loadPlatform() {
        webView.loadUrl(DEFAULT_PLATFORM_URL);
    }

    private void refreshPlatform() {
        if (webView.getUrl() == null || webView.getUrl().isEmpty()) {
            loadPlatform();
            return;
        }
        webView.reload();
    }

    private void parseCurrentPage() {
        webView.evaluateJavascript(EXTRACT_SCRIPT, value -> {
            String extracted = decodeJavascriptString(value);
            try {
                List<Course> courses = BistuCoursePageParser.parse(extracted);
                int inserted = courseRepository.insertCoursesSkippingDuplicates(courses);
                int skipped = courses.size() - inserted;
                Toast.makeText(
                        this,
                        getString(R.string.bistu_import_success, inserted, skipped),
                        Toast.LENGTH_LONG
                ).show();
                debugInfoTextView.setVisibility(View.GONE);
            } catch (BistuCoursePageParser.ParseException e) {
                Toast.makeText(
                        this,
                        getString(R.string.bistu_import_failed, e.getMessage()),
                        Toast.LENGTH_LONG
                ).show();
                showDebugInfo(extracted, null, 0, 0, e.getMessage());
            }
        });
    }

    private void showDebugInfo(String extracted, List<Course> courses, int inserted, int skipped, String error) {
        StringBuilder debug = new StringBuilder();
        debug.append("提取统计: ")
                .append("VISIBLE_COURSE=").append(countMarker(extracted, "VISIBLE_COURSE"))
                .append(", HEADER=").append(countMarker(extracted, "HEADER"))
                .append(", TERM=").append(countMarker(extracted, "TERM"))
                .append(", CANDIDATE=").append(countMarker(extracted, "CANDIDATE"))
                .append('\n');

        if (error != null) {
            debug.append("解析错误: ").append(error).append('\n');
        } else {
            debug.append("入库统计: 新增=").append(inserted)
                    .append(", 跳过=").append(skipped)
                    .append(", 解析=").append(courses == null ? 0 : courses.size())
                    .append('\n');
        }

        debug.append("TERM标记:\n");
        debug.append("VISIBLE_COURSE标记:\n");
        debug.append("HEADER标记:\n");
        debug.append("CANDIDATE标记:\n");

        debug.append("为保护账号和个人信息，调试区不显示网页原始文本。\n");
        boolean includeParsedDetails = false;
        if (includeParsedDetails && courses != null) {
            debug.append("解析结果:\n");
            int limit = Math.min(courses.size(), 30);
            for (int i = 0; i < limit; i++) {
                Course course = courses.get(i);
                debug.append(i + 1)
                        .append(". 周").append(course.getWeekday())
                        .append(" 第").append(course.getStartSection())
                        .append("-").append(course.getEndSection()).append("节 ")
                        .append(course.getStartWeek()).append("-").append(course.getEndWeek()).append("周 ")
                        .append(course.getCourseName())
                        .append(" @").append(course.getClassroom())
                        .append('\n');
            }
        }

        debugInfoTextView.setText(debug.toString());
        debugInfoTextView.setVisibility(View.VISIBLE);
    }

    private int countMarker(String text, String markerName) {
        if (text == null || text.isEmpty()) {
            return 0;
        }
        Matcher matcher = Pattern.compile("\\[\\[" + markerName + "(?:\\s|\\])").matcher(text);
        int count = 0;
        while (matcher.find()) {
            count++;
        }
        return count;
    }

    private void appendMarkedBlocks(StringBuilder debug, String text, String markerName,
                                    String attributeRegex, int limit) {
        if (text == null || text.isEmpty()) {
            return;
        }
        Pattern blockPattern = Pattern.compile(
                "\\[\\[" + markerName + "([^\\]]*)\\]\\]\\n([\\s\\S]*?)(?=\\n\\[\\[|\\z)"
        );
        Pattern attributePattern = Pattern.compile(attributeRegex);
        Matcher matcher = blockPattern.matcher(text);
        int count = 0;
        while (matcher.find() && count < limit) {
            count++;
            String attributes = matcher.group(1);
            String blockText = matcher.group(2).replace('\n', ' ').trim();
            String attributeValue = "?";
            if (!attributeRegex.isEmpty()) {
                Matcher attributeMatcher = attributePattern.matcher(attributes);
                attributeValue = attributeMatcher.find() ? attributeMatcher.group(1) : "?";
            }
            debug.append(count)
                    .append(". value=").append(attributeValue)
                    .append(" text=").append(truncate(blockText, 90))
                    .append('\n');
        }
        if (count == 0) {
            debug.append("无").append(markerName).append("标记\n");
        }
    }

    private String truncate(String value, int maxLength) {
        if (value == null || value.length() <= maxLength) {
            return value == null ? "" : value;
        }
        return value.substring(0, maxLength) + "...";
    }

    private String decodeJavascriptString(String value) {
        if (value == null || "null".equals(value)) {
            return "";
        }
        try {
            return new JSONArray("[" + value + "]").getString(0);
        } catch (JSONException e) {
            return value;
        }
    }
}
