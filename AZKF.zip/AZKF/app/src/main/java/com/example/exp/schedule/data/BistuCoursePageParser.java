package com.example.exp.schedule.data;

import com.example.exp.schedule.model.Course;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class BistuCoursePageParser {
    private static final int DEFAULT_START_WEEK = 1;
    private static final int DEFAULT_END_WEEK = 25;

    private static final Pattern VISIBLE_COURSE_PATTERN = Pattern.compile(
            "\\[\\[VISIBLE_COURSE[^\\]]*weekday=(\\d+)[^\\]]*\\]\\]\\n([\\s\\S]*?)(?=\\n\\[\\[|\\z)"
    );
    private static final Pattern COURSE_NAME_PATTERN = Pattern.compile(
            "^\\s*([^\\n]{2,100}\\[[A-Za-z0-9_-]+\\])"
    );
    private static final Pattern DETAIL_PATTERN = Pattern.compile(
            "(?:^|\\n)\\s*([^\\n]*?)\\s*\\u7B2C\\s*(\\d{1,2})\\s*\\u8282"
                    + "\\s*[-~\\uFF0D\\u2014\\u81F3\\u5230]\\s*(?:\\u7B2C)?\\s*(\\d{1,2})\\s*\\u8282\\s*"
                    + "([A-Za-z]{2,5}-?[A-Za-z]?\\d{3,4})"
    );
    private static final Pattern ROOM_PATTERN = Pattern.compile("([A-Za-z]{2,5}-?[A-Za-z]?\\d{3,4})");
    private static final Pattern WEEK_TOKEN_PATTERN = Pattern.compile(
            "(\\d{1,2})(?:\\s*[-~\\uFF0D\\u2014\\u81F3\\u5230]\\s*(\\d{1,2}))?\\s*\\u5468"
    );

    private BistuCoursePageParser() {
    }

    public static List<Course> parse(String extractedText) throws ParseException {
        String normalized = normalize(extractedText);
        List<Course> courses = parseVisibleCourses(normalized);
        if (courses.isEmpty()) {
            throw new ParseException("未提取到当前可见课表卡片，请确认页面已显示周课表并等待学期切换加载完成");
        }
        return courses;
    }

    private static List<Course> parseVisibleCourses(String text) {
        List<Course> courses = new ArrayList<>();
        Set<String> keys = new HashSet<>();
        Matcher matcher = VISIBLE_COURSE_PATTERN.matcher(text);
        while (matcher.find()) {
            int weekday = parseIntOrDefault(matcher.group(1), -1);
            parseVisibleCourseBlockInto(courses, keys, weekday, cleanText(matcher.group(2)));
        }
        return courses;
    }

    private static void parseVisibleCourseBlockInto(List<Course> courses, Set<String> keys,
                                                    int weekday, String blockText) {
        if (weekday < 1 || weekday > 7 || blockText.isEmpty()) {
            return;
        }

        Matcher nameMatcher = COURSE_NAME_PATTERN.matcher(blockText);
        if (!nameMatcher.find()) {
            return;
        }
        String courseName = nameMatcher.group(1).trim();

        Matcher detailMatcher = DETAIL_PATTERN.matcher(blockText);
        if (!detailMatcher.find()) {
            return;
        }

        String beforeSection = detailMatcher.group(1).trim();
        int startSection = parseIntOrDefault(detailMatcher.group(2), -1);
        int endSection = parseIntOrDefault(detailMatcher.group(3), startSection);
        String classroom = detailMatcher.group(4).trim();
        String teacher = parseTeacher(beforeSection);
        List<int[]> weekRanges = parseWeekRanges(beforeSection);
        if (weekRanges.isEmpty()) {
            weekRanges.add(new int[]{DEFAULT_START_WEEK, DEFAULT_END_WEEK});
        }

        for (int[] weekRange : weekRanges) {
            Course course = buildCourse(courseName, teacher, classroom, weekday,
                    startSection, endSection, weekRange[0], weekRange[1]);
            if (course != null && keys.add(buildKey(course))) {
                courses.add(course);
            }
        }
    }

    private static List<int[]> parseWeekRanges(String text) {
        List<int[]> ranges = new ArrayList<>();
        Matcher matcher = WEEK_TOKEN_PATTERN.matcher(text);
        while (matcher.find()) {
            int startWeek = parseIntOrDefault(matcher.group(1), DEFAULT_START_WEEK);
            int endWeek = matcher.group(2) == null
                    ? startWeek
                    : parseIntOrDefault(matcher.group(2), startWeek);
            ranges.add(new int[]{startWeek, endWeek});
        }
        return ranges;
    }

    private static String parseTeacher(String text) {
        String teacher = text.replaceAll("\\d{1,2}\\s*[-~\\uFF0D\\u2014\\u81F3\\u5230]?\\s*\\d{0,2}\\s*\\u5468", "")
                .replaceAll("[,，、]", " ")
                .replaceAll("\\[[^\\]]*\\]", "")
                .trim();
        return teacher.length() > 40 ? teacher.substring(0, 40) : teacher;
    }

    private static Course buildCourse(String courseName, String teacher, String classroom,
                                      int weekday, int startSection, int endSection,
                                      int startWeek, int endWeek) {
        if (courseName.isEmpty() || weekday < 1 || weekday > 7 || startSection < 1 || endSection < 1) {
            return null;
        }
        Matcher roomMatcher = ROOM_PATTERN.matcher(classroom);
        if (!roomMatcher.find()) {
            return null;
        }

        Course course = new Course();
        course.setCourseName(courseName);
        course.setTeacher(teacher);
        course.setClassroom(roomMatcher.group(1));
        course.setWeekday(weekday);
        course.setStartSection(clamp(startSection, 1, 14));
        course.setEndSection(clamp(endSection, course.getStartSection(), 14));
        course.setStartWeek(clamp(startWeek, 1, 25));
        course.setEndWeek(clamp(endWeek, course.getStartWeek(), 25));
        course.setNote("\u5317\u4EAC\u4FE1\u606F\u79D1\u6280\u5927\u5B66\u6559\u5B66\u7BA1\u7406\u5E73\u53F0\u5BFC\u5165");
        course.setCreatedAt(System.currentTimeMillis());
        return course;
    }

    private static String normalize(String value) {
        return value == null
                ? ""
                : value.replace("\r", "\n")
                .replace("\\n", "\n")
                .replace('\u3010', '[')
                .replace('\u3011', ']')
                .replace("&nbsp;", " ")
                .replace("&amp;", "&")
                .replaceAll("[\\t ]+", " ")
                .trim();
    }

    private static String cleanText(String value) {
        return normalize(value)
                .replaceAll("(?m)^\\s*\\[\\[[^\\]]+\\]\\]\\s*$", "")
                .replaceAll("\\n{3,}", "\n\n")
                .trim();
    }

    private static int parseIntOrDefault(String value, int defaultValue) {
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static String buildKey(Course course) {
        return course.getCourseName() + "|"
                + course.getWeekday() + "|"
                + course.getStartSection() + "|"
                + course.getEndSection() + "|"
                + course.getStartWeek() + "|"
                + course.getEndWeek() + "|"
                + course.getClassroom();
    }

    public static class ParseException extends Exception {
        public ParseException(String message) {
            super(message);
        }
    }
}
