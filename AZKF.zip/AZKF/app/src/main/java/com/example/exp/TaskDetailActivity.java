package com.example.exp;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.exp.data.TaskContract;
import com.example.exp.model.Task;
import com.example.exp.util.DateTimeUtil;
import com.example.exp.util.ReminderUtil;

public class TaskDetailActivity extends AppCompatActivity {
    public static final String EXTRA_TASK_ID = "task_id";

    private long taskId = -1;
    private Task currentTask;

    private TextView titleTextView;
    private TextView contentTextView;
    private TextView deadlineTextView;
    private TextView remindTimeTextView;
    private TextView priorityTextView;
    private TextView statusTextView;
    private TextView remindedTextView;
    private Button markCompletedButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_task_detail);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        taskId = getIntent().getLongExtra(EXTRA_TASK_ID, -1);
        bindViews();
        bindActions();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadTask();
    }

    private void bindViews() {
        titleTextView = findViewById(R.id.tvTaskTitle);
        contentTextView = findViewById(R.id.tvTaskContent);
        deadlineTextView = findViewById(R.id.tvDeadline);
        remindTimeTextView = findViewById(R.id.tvRemindTime);
        priorityTextView = findViewById(R.id.tvPriority);
        statusTextView = findViewById(R.id.tvStatus);
        remindedTextView = findViewById(R.id.tvReminded);
        markCompletedButton = findViewById(R.id.btnMarkCompleted);
    }

    private void bindActions() {
        ImageButton backButton = findViewById(R.id.btnBack);
        backButton.setOnClickListener(v -> finish());

        markCompletedButton.setOnClickListener(v -> markCompleted());

        Button editButton = findViewById(R.id.btnEditTask);
        editButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddTaskActivity.class);
            intent.putExtra(EXTRA_TASK_ID, taskId);
            startActivity(intent);
        });

        Button deleteButton = findViewById(R.id.btnDeleteTask);
        deleteButton.setOnClickListener(v -> deleteTask());
    }

    private void loadTask() {
        if (taskId <= 0) {
            Toast.makeText(this, R.string.task_not_found, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        Uri taskUri = ContentUris.withAppendedId(TaskContract.TaskEntry.CONTENT_URI, taskId);
        try (Cursor cursor = getContentResolver().query(taskUri, null, null, null, null)) {
            if (cursor == null || !cursor.moveToFirst()) {
                Toast.makeText(this, R.string.task_not_found, Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
            currentTask = readTaskFromCursor(cursor);
        }

        renderTask();
    }

    private void renderTask() {
        titleTextView.setText(currentTask.getTitle());
        contentTextView.setText(currentTask.getContent());
        deadlineTextView.setText(getString(
                R.string.deadline_label,
                DateTimeUtil.formatDateTime(currentTask.getDeadlineTime())
        ));
        remindTimeTextView.setText(getString(
                R.string.remind_time_label,
                DateTimeUtil.formatDateTime(currentTask.getRemindTime())
        ));
        priorityTextView.setText(getString(
                R.string.priority_value_label,
                getPriorityText(currentTask.getPriority())
        ));
        statusTextView.setText(getString(
                R.string.status_value_label,
                getStatusText(currentTask.getCompleted())
        ));
        remindedTextView.setText(getString(
                R.string.reminded_value_label,
                getRemindedText(currentTask.getReminded())
        ));

        boolean completed = currentTask.getCompleted() == TaskContract.TaskEntry.STATUS_COMPLETED;
        markCompletedButton.setEnabled(!completed);
        markCompletedButton.setVisibility(completed ? View.GONE : View.VISIBLE);
    }

    private void markCompleted() {
        ContentValues values = new ContentValues();
        values.put(TaskContract.TaskEntry.COLUMN_COMPLETED, TaskContract.TaskEntry.STATUS_COMPLETED);

        Uri taskUri = ContentUris.withAppendedId(TaskContract.TaskEntry.CONTENT_URI, taskId);
        int updated = getContentResolver().update(taskUri, values, null, null);
        if (updated > 0) {
            ReminderUtil.cancelReminder(this, taskId);
            Toast.makeText(this, R.string.task_completed_success, Toast.LENGTH_SHORT).show();
            loadTask();
        } else {
            Toast.makeText(this, R.string.task_update_failed, Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteTask() {
        Uri taskUri = ContentUris.withAppendedId(TaskContract.TaskEntry.CONTENT_URI, taskId);
        int deleted = getContentResolver().delete(taskUri, null, null);
        if (deleted > 0) {
            ReminderUtil.cancelReminder(this, taskId);
            Toast.makeText(this, R.string.task_delete_success, Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, R.string.task_delete_failed, Toast.LENGTH_SHORT).show();
        }
    }

    private Task readTaskFromCursor(Cursor cursor) {
        Task task = new Task();
        task.setId(cursor.getLong(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry._ID)));
        task.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_TITLE)));
        task.setContent(cursor.getString(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_CONTENT)));
        task.setDeadlineTime(cursor.getLong(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_DEADLINE_TIME)));
        task.setRemindTime(cursor.getLong(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_REMIND_TIME)));
        task.setPriority(cursor.getInt(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_PRIORITY)));
        task.setCompleted(cursor.getInt(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_COMPLETED)));
        task.setReminded(cursor.getInt(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_REMINDED)));
        task.setCreatedAt(cursor.getLong(cursor.getColumnIndexOrThrow(TaskContract.TaskEntry.COLUMN_CREATED_AT)));
        return task;
    }

    private String getPriorityText(int priority) {
        if (priority == TaskContract.TaskEntry.PRIORITY_LOW) {
            return getString(R.string.priority_low);
        }
        if (priority == TaskContract.TaskEntry.PRIORITY_HIGH) {
            return getString(R.string.priority_high);
        }
        return getString(R.string.priority_medium);
    }

    private String getStatusText(int completed) {
        return completed == TaskContract.TaskEntry.STATUS_COMPLETED
                ? getString(R.string.status_completed)
                : getString(R.string.status_uncompleted);
    }

    private String getRemindedText(int reminded) {
        return reminded == TaskContract.TaskEntry.REMINDED_YES
                ? getString(R.string.reminded_yes)
                : getString(R.string.reminded_no);
    }
}
