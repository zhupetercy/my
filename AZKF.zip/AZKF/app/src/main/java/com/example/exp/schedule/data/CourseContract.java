package com.example.exp.schedule.data;

import android.provider.BaseColumns;

public final class CourseContract {
    private CourseContract() {
    }

    public static final class CourseEntry implements BaseColumns {
        public static final String TABLE_NAME = "course";

        public static final String COLUMN_COURSE_NAME = "course_name";
        public static final String COLUMN_TEACHER = "teacher";
        public static final String COLUMN_CLASSROOM = "classroom";
        public static final String COLUMN_WEEKDAY = "weekday";
        public static final String COLUMN_START_SECTION = "start_section";
        public static final String COLUMN_END_SECTION = "end_section";
        public static final String COLUMN_START_WEEK = "start_week";
        public static final String COLUMN_END_WEEK = "end_week";
        public static final String COLUMN_NOTE = "note";
        public static final String COLUMN_CREATED_AT = "created_at";

        private CourseEntry() {
        }
    }
}
